<?php
require_once('resgate-post-type.php');
require_once('resgate-cmb.php');
require_once('resgate-colunas.php');
