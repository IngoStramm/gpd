jQuery(function ($) {
    $(document).ready(function () {
        $('.js-example-basic-multiple').select2({
            // placeholder: 'Selecionar um usuário',
            allowClear: true,
            dropdownAutoWidth: true,
            language: 'pt-BR',
            width: '100%'
        });
    });
});