<?php
require_once('recompensa-post-type.php');
require_once('recompensa-cmb.php');