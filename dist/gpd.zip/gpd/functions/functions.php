<?php
$gpd_moeda = new GPD_Moeda;
require_once 'editor-role.php';
require_once 'gpd-admin.php';
require_once 'custom-hooks.php';
require_once 'resgate.php';
require_once 'login.php';
require_once 'general.php';
require_once 'shortcodes.php';
require_once 'recompensas.php';