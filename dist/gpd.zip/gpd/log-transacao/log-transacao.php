<?php
require_once('log-transacao-post-type.php');
require_once('log-transacao-taxonomy.php');
require_once('log-transacao-cmb.php');
require_once('log-transacao-colunas.php');